﻿/*
this script will allow a user to go to a new Scene.
*/

using UnityEngine;
using System.Collections;

using UnityEngine.SceneManagement;

public class GoToScene : MonoBehaviour {

	/*<summary>Scene Index to go to<summary>*/
	public int SceneNum;

	//function to run when button is pressed
	public void Press()
	{
		Time.timeScale = 1f;

		if (SceneManager.sceneCountInBuildSettings > SceneNum)
		{
			GameObject.FindObjectOfType<SceneTransition>().GoToScene(SceneNum,true);
		}
		else
		{
			//if the scene does not exist
			Debug.LogError("Scene does not Exist");
		}

	}

}
