﻿/*
this script manages sets the Text at the begining of the Level
*/

using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class SetLevelText : MonoBehaviour {

	void Awake()
	{

		if (PlayerPrefs.HasKey("CurrentLevelNum"))
		{
			gameObject.GetComponent<Text>().text = "Level " + PlayerPrefs.GetInt("CurrentLevelNum").ToString();
		}

	}
}
