﻿/*
this script manages the Star
*/

using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections;
using System.Collections.Generic;

public class StarStateMachine : MonoBehaviour {


	/*<summary>Possible Star States<summary>*/
	public enum StarStates
	{
		INACTIVE,
		IDLE,
		PULLED,
		RELEASE,
		DIE,
	}

	/*<summary>the current Star State<summary>*/
	public StarStates StarState = StarStates.INACTIVE;

	/*<summary>Maps the methods to the states<summary>*/
	protected Dictionary<StarStates, Action> fms = new Dictionary<StarStates, Action>();

	/*<summary>
	the distance a touch must be to register
	<summary>*/
	public float touchDistance = 1.5f;

	/*<summary>
	the maximum distance you can pull back
	<summary>*/
	public float maxPullDistance = 1f;

	/*<summary>
	the maximum force that will be added to the object
	<summary>*/
	public float forceFactor = 10f;

	/*<summary>
	the number of bounces
	<summary>*/
	public int bounceCount = 0;

	/*<summary>
	the max number of bounces
	<summary>*/
	public int maxBounceCount = 5;

	/*<summary>
	the text that displays the bounceCount
	<summary>*/
	private Text bounceDisplay;

	/*<summary>
	the sound for collision
	<summary>*/
	public AudioClip collisionSound;

	/*<summary>
	the sound for death
	<summary>*/
	public AudioClip dieSound;

	/*<summary>
	the sound for win
	<summary>*/
	public AudioClip winSound;

	/*<summary>
	the sound for release
	<summary>*/
	public AudioClip releaseSound;

	/*<summary>
	the AudioSource that will play the sound
	<summary>*/
	private AudioSource audioSource; 

	/*<summary>
	the particles for collision
	<summary>*/
	public GameObject collisionParticles;

	/*<summary>
	the particles for die
	<summary>*/
	public GameObject dieParticles;

	/*<summary>
	the particles for win
	<summary>*/
	public GameObject WinParticles;

	/*<summary>
	the particles for idel
	<summary>*/
	public ParticleSystem IdelParticleSystem;

	/*<summary>
	Allow to pull the object again
	<summary>*/
	public bool AllowRepull =  true;

	//the position where the pull starts
	private Vector2 startPullPosition;

	//the position where the pull is released
	private Vector2 releasePosition;

	//the mouse's position
	private Vector3 mousePos;

	//the time when the object was released
	private float releaseTime;

	//a tip that will be displayed to reset the level
	private Text TipText;

	//used to render the pull back line
	private LineRenderer lineRenderer;

	//the angle the object is pulled back
	private float pullAngle;

	//the distance the object is pulled back
	private float pullDistance;

	//set some default values
	void Awake()
	{
		//set the lineRenerer
		lineRenderer = gameObject.transform.FindChild("Line").GetComponent<LineRenderer>();

		//maps the States to the methods
		fms.Add (StarStates.INACTIVE,Inactive);
		fms.Add (StarStates.IDLE,Idle);
		fms.Add (StarStates.PULLED,Pulled);
		fms.Add (StarStates.RELEASE,Release);
		fms.Add (StarStates.DIE,Die);

		//get the bounceDisplay
		if (gameObject.transform.GetComponentInChildren<Text>() != null)
		{
			bounceDisplay = gameObject.transform.GetComponentInChildren<Text>();
			bounceDisplay.text = maxBounceCount.ToString();
		}

		//set the AudioSource
		if (GameObject.Find("AudioSource") != null)
		{
			audioSource =  GameObject.Find("AudioSource").GetComponent<AudioSource>();
		}

		//set the TipText
		if (GameObject.Find("Tip") != null)
		{
			TipText =  GameObject.Find("Tip").GetComponent<Text>();

			TipText.color = new Color(1f,1f,1f,0f);
		}

	}

	//this method will be used to change the state
	public void SetState(StarStates NextState)
	{
		StarState =  NextState;

		if (NextState != StarStates.IDLE
		    && IdelParticleSystem != null)
		{
			IdelParticleSystem.Stop(); 
		}

		if (
			(NextState == StarStates.IDLE || AllowRepull)
		    && IdelParticleSystem != null)
		{
			IdelParticleSystem.Play();
		}
	}

	void Update () 
	{
		//get the mouse position
		mousePos = Input.mousePosition;
		mousePos = Camera.main.ScreenToWorldPoint( mousePos);
		mousePos.z = 0f;

		//invoke the method the corresponds to the current state
		fms[StarState].Invoke();

		//show the TipText (if releaseTime is over 3 seconds ago)
		if (Time.time - releaseTime >= 3f
			&& releaseTime != 0f 
			)
		{
			float a = TipText.color.a;

			a = Mathf.Sin( ((Time.time - releaseTime) - 3f) * 2f) * 2;
			
			TipText.color = new Color(TipText.color.r,TipText.color.g,TipText.color.b,a);
		}

	}

	//execute during Inactive State
	private void Inactive()
	{

	}

	//execute during Idle State
	private void Idle()
	{
		if (Input.GetMouseButtonDown(0))
		{
			if (Vector2.Distance(gameObject.transform.position,mousePos) < touchDistance)
			{
				startPullPosition = Input.mousePosition;
				SetState(StarStates.PULLED);
			}
		}
	}

	//execute during Pulled State
	private void Pulled()
	{
		lineRenderer.SetPosition(0,gameObject.transform.position);

		pullAngle = GetAngleDirection(gameObject.transform.position,mousePos);

		pullDistance = Vector2.Distance(gameObject.transform.position,mousePos);
		pullDistance = Mathf.Clamp(pullDistance,0f,maxPullDistance);

		Vector2 pos = GetXYDirection(pullAngle,pullDistance);

		pos = new Vector2(gameObject.transform.position.x,gameObject.transform.position.y) + pos;

		lineRenderer.SetPosition(1,pos);

		if (Input.GetMouseButtonUp(0))
		{
			lineRenderer.SetPosition(0,gameObject.transform.position);
			lineRenderer.SetPosition(1,gameObject.transform.position);

			Vector2 force = GetXYDirection(pullAngle,(pullDistance/maxPullDistance) * forceFactor) * -1f ;
			gameObject.GetComponent<Rigidbody2D>().AddForce(force);

			releaseTime = Time.time;

			SetState(StarStates.RELEASE);

			if (audioSource != null)
			{
				audioSource.PlayOneShot(releaseSound);
			}

		}

	}

	//execute during Release State
	private void Release()
	{

		if (AllowRepull)
		{
			if (Input.GetMouseButtonDown(0))
			{
				if (Vector2.Distance(gameObject.transform.position,mousePos) < touchDistance)
				{
					startPullPosition = Input.mousePosition;
					SetState(StarStates.PULLED);
				}
			}
		}
	}
	
	//execute during Die State
	private void Die()
	{
		if (dieParticles != null)
		{
			GameObject.Instantiate(dieParticles,gameObject.transform.position,gameObject.transform.rotation);
		}

		if (audioSource != null)
		{
			audioSource.PlayOneShot(dieSound);
		}

		Destroy(gameObject);
	}

	//if the Star Collides with anything
	void OnCollisionEnter2D(Collision2D coll) 
	{
		if (
			coll.collider.gameObject.tag == "Boarder"
			|| coll.collider.gameObject.tag == "Block"
		    )
		{

			bounceCount += 1;

			if (bounceCount >= maxBounceCount)
			{
				SetState(StarStates.DIE);
			}

			if (bounceDisplay != null)
			{
				bounceDisplay.text = (maxBounceCount - bounceCount).ToString();
			}


			if (collisionParticles == null)
			{
				return;
			}

			for (int i =0; i < coll.contacts.Length; i++)
			{
				GameObject.Instantiate(collisionParticles,coll.contacts[i].point,gameObject.transform.rotation);
			}

			if (audioSource != null)
			{
				audioSource.PlayOneShot(collisionSound);
			}
		}
	}

	//if the Star Touches the StarGate
	void OnTriggerEnter2D(Collider2D other) 
	{
		if (other.gameObject.tag == "StarGate")
		{
			if (WinParticles != null)
			{
				GameObject.Instantiate(WinParticles,other.gameObject.transform.position,gameObject.transform.rotation);
			}

			if (audioSource != null)
			{
				audioSource.PlayOneShot(winSound);
			}
			
			Destroy(gameObject);
			
			Destroy(other.gameObject);
		}
	}

	//allows to set a new maxBounceCount
	public void SetNewMaxBounceCount(int NMBC)
	{
		maxBounceCount = NMBC;

		if (gameObject.transform.GetComponentInChildren<Text>() != null)
		{
			bounceDisplay = gameObject.transform.GetComponentInChildren<Text>();
			bounceDisplay.text = maxBounceCount.ToString();
		}
	}
	
	//gets the XY coordinates using the Angle and the Magnitude
	private Vector2 GetXYDirection( float angle, float magnitude)
	{
		angle *= -1f;
		angle -= 90f;
		return new Vector2(Mathf.Cos(angle * Mathf.Deg2Rad), Mathf.Sin(angle * Mathf.Deg2Rad)) * magnitude;
	}

	//gets the Angle using the origin point and another point
	private float GetAngleDirection( Vector2 point1, Vector2 point2)
	{
		Vector2 v = point1 - point2;
		
		return (float)Mathf.Atan2(v.x, v.y) * Mathf.Rad2Deg; 
	}
		

}
