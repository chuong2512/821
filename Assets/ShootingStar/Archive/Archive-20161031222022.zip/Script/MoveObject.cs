﻿/*
this script manages the movement of objects
*/

using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

public class MoveObject : MonoBehaviour {

	/*<summary>possible move states<summary>*/
	public enum MoveStates
	{
		INACTIVE,
		MOVE,
		WAIT,
	}

	/*<summary>current move state<summary>*/
	public MoveStates moveState = MoveStates.INACTIVE;

	/*<summary>previous move state<summary>*/
	public MoveStates moveState_prev = MoveStates.MOVE;

	/*<summary>Maps the functions to the states<summary>*/
	protected Dictionary<MoveStates, Action> fms = new Dictionary<MoveStates, Action>();

	/*<summary>transitions that the object will move between<summary>*/
	public List<Transform> Transforms = new List<Transform>();

	/*<summary>the index of the current transform<summary>*/
	private int transformIndex = 1;

	/*<summary>the speed of position change<summary>*/
	public float positionSpeed;

	/*<summary>the speed of rotation change<summary>*/
	public float rotationSpeed;

	/*<summary>the speed of scale change<summary>*/
	public float scaleSpeed;

	/*<summary>time to wait between transitions<summary>*/
	public float waitTime;

	/*<summary>used to store the time waiting starts<summary>*/
	private float StartWaitTime;

	/*<summary>used if cycle type if pingpong<summary>*/
	private int PingPongDirection = 1;

	/*<summary>possible cycle types<summary>*/
	public enum CycleTypes
	{
		LOOP,
		PINGPONG,
	}

	/*<summary>current cycle type<summary>*/
	public CycleTypes CycleType = CycleTypes.LOOP;

	void Awake()
	{
		if (Transforms.Count < 2)
		{
			Debug.Log("you need 2 or more transitions");
		}

		fms.Add (MoveStates.INACTIVE,Inactive);
		fms.Add (MoveStates.MOVE,Move);
		fms.Add (MoveStates.WAIT,Wait);

		gameObject.transform.position = Transforms[0].position;
		gameObject.transform.rotation = Transforms[0].rotation;
		gameObject.transform.localScale = Transforms[0].localScale;
		transformIndex = 1;
	}

	void FixedUpdate () 
	{
		//execute current state
		fms[moveState].Invoke();
	}

	//used to change state
	public void SetState(MoveStates NextState)
	{
		moveState_prev = moveState;
		moveState =  NextState;

		if (NextState == MoveStates.WAIT)
		{
			StartWaitTime = Time.time;
		}
			
	}

	//used to set to the previous state
	public void SetPrevState()
	{
		SetState(moveState_prev);
	}

	//used to move the object
	private void Move()
	{
		gameObject.transform.position = Vector3.Lerp(gameObject.transform.position,Transforms[transformIndex].position, Time.deltaTime * positionSpeed);
		gameObject.transform.rotation = Quaternion.Lerp(gameObject.transform.rotation,Transforms[transformIndex].rotation, Time.deltaTime * rotationSpeed);
		gameObject.transform.localScale = Vector3.Lerp(gameObject.transform.localScale,Transforms[transformIndex].localScale, Time.deltaTime * scaleSpeed);

		if (
			Vector3.Distance(gameObject.transform.position,Transforms[transformIndex].position) < 0.05f
			&& Vector3.Distance(gameObject.transform.localScale,Transforms[transformIndex].localScale) < 0.05f
			&& Vector3.Distance(gameObject.transform.rotation.eulerAngles,Transforms[transformIndex].rotation.eulerAngles) < 0.05f
			)
		{
			if (CycleType == CycleTypes.LOOP)
			{
				transformIndex = (transformIndex + 1) % Transforms.Count;
			}
			else if (CycleType == CycleTypes.PINGPONG)
			{
				

				if (
					(transformIndex + PingPongDirection) < 0
					||
					(transformIndex + PingPongDirection) >= Transforms.Count
					)
				{
					PingPongDirection *= -1;
				}

				transformIndex = transformIndex + PingPongDirection;
			}

			SetState(MoveStates.WAIT);
		}
	}

	//used during wait state
	private void Wait()
	{
		if (Time.time - StartWaitTime > waitTime)
		{
			SetState(MoveStates.MOVE);
		}
	}

	//used during inactive state
	private void Inactive()
	{

	}

	//used to reset the object's movment
	public void Reset()
	{
		gameObject.transform.position = Transforms[0].position;
		gameObject.transform.rotation = Transforms[0].rotation;
		gameObject.transform.localScale = Transforms[0].localScale;

		transformIndex = 1;
	}

}
