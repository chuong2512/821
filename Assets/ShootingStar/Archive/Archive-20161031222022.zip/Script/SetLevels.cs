﻿/*
this script manages LevelData

links each LevelButton to a Scene.
Locks/Unlocks Levels
Delete LevelData (in the PlayerPrefs)

*/

using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class SetLevels : MonoBehaviour {

	//this is the first level...the loop below will incrment this number
	private int LevelNum = 1;

	/*<summary>
	This number is the difference between the level number and the scene number.
	Example if level 1 is scene 4 then the LevelNumSceneNumOffset should be 3.
	<summary>*/
	public int LevelNumSceneNumOffset = 0;

	/*<summary>the number of levels won<summary>*/
	public int LevelWonCount = 0;

	/*<summary>Delete All LevelData<summary>*/
	public bool DeleteAllLevelData = false;

	void Awake()
	{
		
		if (DeleteAllLevelData)
		{
			PlayerPrefs.DeleteAll(); //deletes all Player.Prefs
		}

		//gets the number of levels Won
		LevelWonCount = GetWonCount(); 



		//Loop through each LevelButton and sets data about the Level
		for(int i = 0; i < gameObject.transform.childCount ; i++)
		{
			for(int j = 0; j < gameObject.transform.GetChild(i).gameObject.transform.childCount ; j++)
			{
				if (gameObject.transform.GetChild(i).gameObject.transform.GetChild(j).GetComponent<LevelButton>())
				{
					//set the Level
					SetLevelStatus(LevelNum, gameObject.transform.GetChild(i).gameObject.transform.GetChild(j).GetComponent<LevelButton>());

					//increment the LevelNum
					LevelNum += 1;
				}

			}
		}

		PlayerPrefs.SetInt("FinalLevel",LevelNum-1);

		//get data from the GridLayoutGroup
		Vector2 CellSize = gameObject.GetComponent<GridLayoutGroup>().cellSize;
		Vector2 CellSpacing = gameObject.GetComponent<GridLayoutGroup>().spacing;

		//change the size of the RectTransform in case more levelGroups where made
		gameObject.GetComponent<RectTransform>().sizeDelta=new Vector2((CellSize.x * gameObject.transform.childCount) + (CellSpacing.x * (gameObject.transform.childCount-1)),gameObject.GetComponent<RectTransform>().rect.height);

		//save the data
		PlayerPrefs.Save();
	}
		

	//this method sets the LevelNum,matches the Level with it's Scene, sets the Lock/Unlock status
	public void SetLevelStatus(int LN, LevelButton LB)
	{
		LB.LevelNum = LN;
		LB.SceneNum = LN + LevelNumSceneNumOffset;

		if (LevelWonCount + 3 >= LN
			&& PlayerPrefs.GetInt("Level" + LN.ToString() + "Status") == 0
		)
		{
			PlayerPrefs.SetInt("Level" + LN.ToString() + "Status",1);
			LB.SetState(LevelButton.LevelStatuses.UNLOCKED);
		}

		if (LN <= 3)
		{
			if (PlayerPrefs.HasKey("Level" + LN.ToString() + "Status"))
			{
				LB.SetState(PlayerPrefs.GetInt("Level" + LN.ToString() + "Status"));

			}
			else
			{
				PlayerPrefs.SetInt("Level" + LN.ToString() + "Status",1);
				LB.SetState(PlayerPrefs.GetInt("Level" + LN.ToString() + "Status"));
			}
		}
		else
		{
			if (PlayerPrefs.HasKey("Level" + LN.ToString() + "Status"))
			{
				LB.SetState(PlayerPrefs.GetInt("Level" + LN.ToString() + "Status"));

			}
			else
			{
				PlayerPrefs.SetInt("Level" + LN.ToString() + "Status",0);
				LB.SetState(PlayerPrefs.GetInt("Level" + LN.ToString() + "Status"));
			}
		}

	}


	//this method loops through each level in Player.Prefs to count the number of levels won.
	public int GetWonCount()
	{
		int i = 1;
		int WonCount = 0;

		while (PlayerPrefs.HasKey("Level" + i.ToString() + "Status"))
		{
			if (PlayerPrefs.GetInt("Level" + i.ToString() + "Status") == 2)
			{
				WonCount += 1;
			}

			i++;
		}

		return WonCount;
	}


}
