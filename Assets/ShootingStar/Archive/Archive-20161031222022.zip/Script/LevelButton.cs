﻿/*
this script manages the LevelButtons
*/

using UnityEngine;
using UnityEngine.UI;
using System.Collections;

using UnityEngine.SceneManagement;

public class LevelButton : MonoBehaviour {

	/*<summary>Possible Level Statuses<summary>*/
	public enum LevelStatuses
	{
		LOCKED = 0,
		UNLOCKED = 1,
		WON = 2,
	}

	/*<summary>Temporarily locks the button when scrolling<summary>*/
	public bool TempLock = false;

	/*<summary>Current Level Status<summary>*/
	public LevelStatuses LevelStatus;

	/*<summary>Level Number<summary>*/
	public int LevelNum;

	/*<summary>Scene Number<summary>*/
	public int SceneNum;

	/*<summary>Lock Sprite<summary>*/
	public Sprite LockSprite;
	/*<summary>Lock Color<summary>*/
	public Color LockColor;

	/*<summary>Win Sprite<summary>*/
	public Sprite WinSprite;
	/*<summary>Win Color<summary>*/
	public Color WinColor;

	void Start()
	{
		//set the Level Text
		gameObject.transform.FindChild("Text").gameObject.GetComponent<Text>().text = LevelNum.ToString();
	}
		

	//set the state for this Level Button
	public void SetState(LevelStatuses NextState)
	{
		//Do not allow the same state to be set Twice
		if (NextState == LevelStatus)
		{
			return;
		}

		//set state
		LevelStatus =  NextState;

		//set the correct icon for this level
		SetIcon();

		//enable this level pending on it's status
		if (LevelStatus == LevelStatuses.LOCKED)
		{
			Disable(true);
		}
		else
		{
			Disable(false);
		}
	}

	//Override set state to be used with integers
	public void SetState(int NextState)
	{
		if (NextState == 0)
		{
			SetState(LevelStatuses.LOCKED);
		}
		else if (NextState == 1)
		{
			SetState(LevelStatuses.UNLOCKED);
		}
		else if (NextState == 2)
		{
			SetState(LevelStatuses.WON);
		}

	}

	//set the Icon for this level
	public void SetIcon()
	{
		if (gameObject.transform.FindChild("Image") == null
		    || gameObject.transform.FindChild("Image").GetComponent<Image>() == null
		    )
		{
			return;
		}

		Image image = gameObject.transform.FindChild("Image").GetComponent<Image>();
		image.color = new Color(1f,1f,1f,0f);

		if (LevelStatus == LevelStatuses.LOCKED)
		{
			image.sprite = LockSprite;
			image.color = LockColor;
		}
		else if (LevelStatus == LevelStatuses.WON)
		{
			image.sprite = WinSprite;
			image.color = WinColor;
		}
	}

	//Action to be performed when pressed
	public void Press()
	{
		//do nothing if locked
		if (TempLock == true
			|| LevelStatus == LevelStatuses.LOCKED
		    )
		{
			print("Temp Lock");

			return;
		}

		PlayerPrefs.SetInt("CurrentLevelNum",LevelNum);
		PlayerPrefs.SetString("CurrentLevelName","Level " + LevelNum.ToString());

		if (SceneManager.sceneCountInBuildSettings > SceneNum)
		{
//			SceneManager.LoadScene(SceneNum);
			GameObject.FindObjectOfType<SceneTransition>().GoToScene(SceneNum,true);
		}
		else
		{
			//if scene doesn't exist
			Debug.LogError("Scene does not Exist");
		}
	}

	//disable the button or not
	public void Disable(bool TF)
	{
		gameObject.GetComponent<Button>().interactable = !TF;
	}
		
}
