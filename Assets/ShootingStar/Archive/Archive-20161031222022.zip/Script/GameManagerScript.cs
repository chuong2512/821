﻿/*
this script will Reset the level or go the Next Level 
*/

using UnityEngine;
using System.Collections;

using UnityEngine.SceneManagement;

public class GameManagerScript : MonoBehaviour {

	/*<summary>The Star Prefab<summary>*/
	public GameObject Star;

	/*<summary>Whether or not to change the Star's Max Bounce Count<summary>*/
	public bool OverrideStarMaxBounceCount = false;

	/*<summary>The Star's New Max Bounce Count<summary>*/
	public int newMaxBounceCount = 10;

	/*<summary>Number of Stars<summary>*/
	public int StarCount = 0;

	/*<summary>Number of StarGates<summary>*/
	public int StarGateCount = 0;

	/*<summary>location of the StarGate<summary>*/
	private Vector3 StarGateLocation;

	/*<summary>Current LeveleNum<summary>*/
	private int LevelNum;

	//used for double tap to reset
	private float tapUpTime;

	void Awake()
	{
		//get Star and StarGateCount
		StarCount =  GameObject.FindGameObjectsWithTag("Star").Length;
		StarGateCount =  GameObject.FindGameObjectsWithTag("StarGate").Length;

		StarGateLocation = GameObject.FindGameObjectWithTag("StarGate").transform.position;

		//get LevelNum
		if (PlayerPrefs.HasKey("CurrentLevelNum"))
		{
			LevelNum = PlayerPrefs.GetInt("CurrentLevelNum");
		}
			
	}

	// Update is called once per frame
	void FixedUpdate () 
	{



		//update Star and StarGateCount
		StarCount =  GameObject.FindGameObjectsWithTag("Star").Length;
		StarGateCount =  GameObject.FindGameObjectsWithTag("StarGate").Length;

		if (StarGateCount > 0)
		{
			StarGateLocation = GameObject.FindGameObjectWithTag("StarGate").transform.position;
		}

		//if StarGateCount is 0 then goto next level
		if (StarGateCount == 0) 
		{
			PlayerPrefs.SetInt("Level" + LevelNum.ToString() + "Status",2);

			PlayerPrefs.Save();

			Invoke("NextLevel",1f);
		}
		else if (
				StarCount == 0
				)
		{
			//if StarCount is 0 then Reset
			Reset();
		}

		bool PullingStar =  false;
		StarStateMachine[] Stars = GameObject.FindObjectsOfType<StarStateMachine>();

		for (int i =0; i < Stars.Length;i++)
		{
			if (Stars[i].StarState == StarStateMachine.StarStates.PULLED)
			{
				PullingStar = true;
			}
		}
	
		//used for double tag to reset
		if (
			Input.GetMouseButtonUp(0)
			&& !PullingStar
			)
		{
			if (Time.time - tapUpTime < 0.5f)
			{
				Reset();
			}

			tapUpTime = Time.time;
		}


	}

	//reset the level
	private void Reset()
	{
		if (StarGateCount == 0)
		{
			return;
		}

		DestoryStars();
		CreateStars();
		ResetObjects();
	}

	//destorys all stars in level
	private void DestoryStars()
	{
		GameObject[] Stars = GameObject.FindGameObjectsWithTag("Star");

		for (int i = 0; i < Stars.Length ;i++)
		{
			Stars[i].GetComponent<StarStateMachine>().SetState(StarStateMachine.StarStates.DIE);
		}
	}

	//recreates stars in the level
	private void CreateStars()
	{
		GameObject[] SpawnPoints = GameObject.FindGameObjectsWithTag("SpawnPoint");

		for (int i = 0; i < SpawnPoints.Length ;i++)
		{
			GameObject NewStar = GameObject.Instantiate(Star,SpawnPoints[i].transform.position,SpawnPoints[i].transform.rotation) as GameObject;

			if (OverrideStarMaxBounceCount)
			{
				NewStar.GetComponent<StarStateMachine>().SetNewMaxBounceCount(newMaxBounceCount);
			}
		}
	}

	//place all objects back in their default locations
	private void ResetObjects()
	{
		MoveObject[] MO = GameObject.FindObjectsOfType<MoveObject>();

		for (int i = 0; i < MO.Length ;i++)
		{
			MO[i].Reset();
		}
	}

	//go to next level
	private void NextLevel()
	{
		int Nlvl = SceneManager.GetActiveScene().buildIndex + 1;


		if ( 
			SceneManager.sceneCountInBuildSettings > Nlvl //make sure the level exists
			&& PlayerPrefs.GetInt("FinalLevel") != SceneManager.GetActiveScene().buildIndex //make sure this level is not the last level
			)
		{
			PlayerPrefs.SetInt("CurrentLevelNum",Nlvl);
			PlayerPrefs.SetString("CurrentLevelName","Level " + Nlvl.ToString());

			PlayerPrefs.Save();

			//Load Next Level Scene
			GameObject.FindObjectOfType<SceneTransition>().GoToScene(Nlvl,StarGateLocation);
		}
		else if ( 
			PlayerPrefs.GetInt("FinalLevel") == SceneManager.GetActiveScene().buildIndex //if it's the last level, go to menu.
				)
		{

			//Load Menu Scene
			GameObject.FindObjectOfType<SceneTransition>().GoToScene(0,StarGateLocation);

		}
		else if (SceneManager.sceneCountInBuildSettings <= Nlvl) //if the level doesn't exist
		{
			Debug.LogError("Scene does not Exist");
			return;
		}
		else
		{
			Debug.LogError("Unknow Error");
			return;
		}

	}

}
