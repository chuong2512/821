﻿/*
this script manages the sets the boarders at the edges of the screen
*/

using UnityEngine;
using UnityEngine.UI;
using System.Collections;


public class SetBoarder : MonoBehaviour {

	/*<summary>Possible positions for the boarder<summary>*/
	public enum BoarderTypes {Top = 0,Right = 1, Bottom = 2, Left = 3};

	/*<summary>the current position for the boarder<summary>*/
	public BoarderTypes boarderType = BoarderTypes.Top;

	//on awake move the borders to the correct locations
	void Awake()
	{
		//this is a ReferencePoint for where to place the boarders
		Vector3 ReferencePoint = Camera.main.ScreenToWorldPoint(new Vector2(0f,0f));

		//get current position and scale
		Vector3 Pos = gameObject.transform.position;
		Vector3 Scale = gameObject.transform.localScale;

		//depending on the boarder move and place where it belongs
		if (boarderType == BoarderTypes.Bottom)
		{
			Pos = new Vector3(0f,ReferencePoint.y,0f);

			Pos.y -= (Scale.y/2f);
			gameObject.transform.position = Pos;

			Scale.x *= Screen.width / (Screen.dpi/3f);
			gameObject.transform.localScale = Scale;

		}
		else if (boarderType == BoarderTypes.Top)
		{
			Pos = new Vector3(0f, -ReferencePoint.y,0f);

			Pos.y += (Scale.y/2f);
			gameObject.transform.position = Pos;

			Scale.x *= Screen.width / (Screen.dpi/3f);
			gameObject.transform.localScale = Scale;
		}
		else if (boarderType == BoarderTypes.Left)
		{
			Pos = new Vector3(ReferencePoint.x,0f,0f);

			Pos.x -= (Scale.x/2f);
			gameObject.transform.position = Pos;

			Scale.y *= Screen.height / (Screen.dpi/3f);
			gameObject.transform.localScale = Scale;
		}
		else if (boarderType == BoarderTypes.Right)
		{
			Pos = new Vector3(-ReferencePoint.x,0f,0f);

			Pos.x += (Scale.x/2f);
			gameObject.transform.position = Pos;

			Scale.y *= Screen.height / (Screen.dpi/3f);
			gameObject.transform.localScale = Scale;

		}

	}
	
}
