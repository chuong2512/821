﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;


public class SceneTransition : MonoBehaviour {

	private int NextSceneInt = 1; //this is the scene we'll be transitioning to 

	private Animator Anim; //this is the Animator we'll be using


	void Start () 
	{
		//just setting some variables
		Anim = GetComponent<Animator>();
	}
	
	private Vector2 TouchPosition; //stores the position the player touched
	void Update() //on update we are setting the latest touch touch position
	{
		Touch[] Touches = Input.touches;

		for (int i = 0; i < Touches.Length;i++) //for each touch set the TouchPosition variable
		{
			if (Touches[i].phase == TouchPhase.Ended)
			{
				TouchPosition = Touches[i].position;
			}
		}

		if (Input.GetMouseButtonDown(0))
		{
			TouchPosition = Input.mousePosition; //yeah we'll do the same for the mouse's position
		}
	}

	public void GoToScene(int SceneInt, bool UseTouchPosition)
	{
		Time.timeScale = 1f;

		NextSceneInt = SceneInt; //we'll save the SceneInt for later in the NextSceneInt variable
		Anim.SetTrigger("SceneTransition"); //this makes the circle grow

		if (UseTouchPosition)
		{
			gameObject.transform.position = TouchPosition; //this moves the circle to the last touch location
		}
		else
		{
			gameObject.transform.position = new Vector2(0f,0f);
		}
	}


	public void GoToScene(int SceneInt, Vector3 Pos)
	{
		Time.timeScale = 1f;

		NextSceneInt = SceneInt; //we'll save the SceneInt for later in the NextSceneInt variable
		Anim.SetTrigger("SceneTransition"); //this makes the circle grow


		Vector3 V3 = Camera.main.WorldToScreenPoint(Pos);
		gameObject.transform.position = V3; //this moves the circle to the last touch location

	}


	public void GoToScene2()
	{
		SceneManager.LoadScene(NextSceneInt);
	}
}
