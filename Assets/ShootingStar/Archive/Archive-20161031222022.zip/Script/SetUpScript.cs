﻿/*
This Script will create new objects on awake
*/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SetUpScript : MonoBehaviour {
	
	//list of objects to create
	public List<GameObject> Objects = new List<GameObject>();
	

	void Awake()
	{
		//for each object create it provided it doesn't already exist
		foreach(GameObject O in Objects)
		{
			if (GameObject.Find (O.name) == null) //make sure it doesn't already exists
			{
				GameObject ThisO = Instantiate(O) as GameObject; //create object
				ThisO.name = ThisO.name.Replace("(Clone)",""); //removed the "(Clone)" from the name
			}
		}

	}


}
