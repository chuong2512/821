﻿/*
this script will make sure objects do not get destoryed when switching scenes
*/

using UnityEngine;
using System.Collections;

public class DontDestroyOnLoad : MonoBehaviour {

	void Awake() 
	{
		DontDestroyOnLoad(transform.gameObject);
	}
		
}
