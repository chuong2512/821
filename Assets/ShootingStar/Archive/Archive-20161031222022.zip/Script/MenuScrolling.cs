﻿/*
this script manages the Scrolling through LevelGroups
*/

using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections;
using System.Collections.Generic;

public class MenuScrolling : MonoBehaviour {

	/*<summary>possible scroll states<summary>*/
	public enum ScrollStates
	{
		IDLE,
		SCROLLING,
		RECOIL,
	}

	/*<summary>current scroll state<summary>*/
	public ScrollStates ScrollState = ScrollStates.IDLE;

	/*<summary>Maps the functions to the states<summary>*/
	protected Dictionary<ScrollStates, Action> fms = new Dictionary<ScrollStates, Action>();

	//mouse positions
	private Vector2 mousePos;
	private Vector2 mousePos_Prev;

	/*<summary>The GameObject that is the parent of all the level groups<summary>*/
	public GameObject LevelGroupParentObject;

	//used for scrolling
	private int Sections = 3;
	private Scrollbar scrollbar;

	/*<summary>Speed of Recoil<summary>*/
	public float RecoilSpeed = 10f;

	//on awake set default values
	void Awake()
	{

		Sections = LevelGroupParentObject.transform.childCount;

		fms.Add (ScrollStates.IDLE,Idle);
		fms.Add (ScrollStates.SCROLLING,Scrolling);
		fms.Add (ScrollStates.RECOIL,Recoil);

		scrollbar = gameObject.GetComponent<Scrollbar>();



	}

	void Start()
	{
		if (PlayerPrefs.HasKey("ScrollBarValue"))
		{
			scrollbar.value = PlayerPrefs.GetFloat("ScrollBarValue");
		}
	}

	void Update()
	{

		mousePos = Input.mousePosition;

		if (Input.GetMouseButtonDown(0))
		{
			mousePos_Prev = mousePos;
		}

		fms[ScrollState].Invoke();

		mousePos_Prev = mousePos;
	}

	//used to set a new state
	public void SetState(ScrollStates NextState)
	{
		ScrollState =  NextState;

		//place a temp lock on the buttons during scrolling
		if (NextState == ScrollStates.SCROLLING)
		{
			LevelButton[] LevelButtons =  GameObject.FindObjectsOfType<LevelButton>();

			for (int i = 0;i < LevelButtons.Length ;i++)
			{
				LevelButtons[i].TempLock = true;
			}
		}

		//unlock the temp lock during idle
		if (NextState == ScrollStates.IDLE)
		{
			LevelButton[] LevelButtons =  GameObject.FindObjectsOfType<LevelButton>();
			
			for (int i = 0;i < LevelButtons.Length ;i++)
			{
				LevelButtons[i].TempLock = false;
			}

		}

	}

	//during idel wait for scorlling
	void Idle () 
	{

		if (
			Input.GetMouseButton(0)
			&& mousePos != mousePos_Prev
		    )
		{
			SetState(ScrollStates.SCROLLING);
		}

	}
	
	// when done scrolling to go recoil
	void Scrolling () 
	{
		if (Input.GetMouseButtonUp(0))
		{
			SetState(ScrollStates.RECOIL);
		}
	}

	// after recoil return to idel
	void Recoil () 
	{

		float lowestValue = 100f;
		int i_low = 0;

		for (int i =0 ;i < Sections;i++)
		{
			if ( Mathf.Abs((float)i/(float)(Sections-1) - scrollbar.value ) < lowestValue)
			{
				lowestValue = Mathf.Abs((float)i/(float)(Sections-1) - scrollbar.value );
				i_low = i;
			}
		}

		//lerp to the new scorll value
		scrollbar.value =  Mathf.Lerp(scrollbar.value, (float)i_low/(float)(Sections-1) ,Time.deltaTime * RecoilSpeed);


		if (Mathf.Abs(scrollbar.value - (float)i_low/(float)(Sections-1)) < 0.01f)
		{
			PlayerPrefs.SetFloat("ScrollBarValue",scrollbar.value);
			SetState(ScrollStates.IDLE);
		}

	}



}
